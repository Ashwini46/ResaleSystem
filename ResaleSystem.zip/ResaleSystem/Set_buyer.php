<?php 
   require('config/config.php');
   
   
?>
<!DOCTYPE html>
<html>
<head>
	<title>Buyer Information</title>
	
  <link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" type="text/css" href="css/purchase.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<style type="text/css">
  footer{
    position: fixed;
    bottom: 0;
    width: 100%;
    
  }
</style>
<body style="background-image: url('./wallimg/benefits-bg.svg');background-color:white;
  background-repeat:repeat ; background-size:100%; position:absolute;"> 
 
	<!--nav class="navbar navbar-inverse"-->
  <div class="container" >
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>
  
 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="Home_2.php">HOME</a></li>
        <li><a href="My_Products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="./Laptop_Mobile.php">ADVERTISE</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<br><br>
<div class="container">
  <h2 style="text-align:center;margin-bottom:50px">Product Sold</h2>
  <form class="form-horizontal" action="set_buyer.php" method="post">
    <div class="form-group">
      <label class="control-label col-sm-3" for="advt_id">Advertisement ID</label>
      <div class="col-sm-9">

      <select class="form-control" id="advt_id" name="advt_id" required style="width:500px;">
      <option>-----------------------------------------------------------------------------------------------</option>
      <?php 
      $email=$_SESSION['email'];
      $sql="SELECT * FROM advertisement_table where owner_id='$email' and buyer_id is null";
      $res=mysqli_query($db,$sql);
      $f=0;
      while($row=mysqli_fetch_assoc($res)){
        $f=intval($row['ad_id']);
        
      echo "<option value='".$row['ad_id']."'>".$row['ad_id']."</option>";
      }
      ?>
      </select>


        <!--input type="nuber" class="form-control" id="advt_id" placeholder="Advertisement ID" name="advt_id" required min=1-->
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-3" for="product_name">Buyer Registered Email Id:</label>
      <div class="col-sm-7">
        <input type="email" class="form-control" id="buyer_email" placeholder="Email Id" name="buyer_email" required>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-3 col-sm-9">
      <a href="Set_buyer.php?advt_id=<?php echo $f;?>"><button type="submit" id="submit" name="submit" class="btn btn-primary" onclick="window.location.href='http://localhost/Myproject/My_Products.php';">Submit</button></a>
      </div>
    </div>
</form>
</div>

<footer>
  <p align='center'>@ 2021 Copyright: <a href="home_2.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>

<?php

if(isset($_POST['submit'])){
  $user_id = $_SESSION['email'];
  $today =  Date("Y-m-d");
	$advt_id =$_POST['advt_id'];
	$buyer_id = mysqli_escape_string($db,$_POST['buyer_email']);
	//check if buyer id is not same to the id which is logged in
	if($user_id == $buyer_id){
		echo "<script type='text/javascript'>alert('Buyer ID cannot be same as Logged in ID')</script>";
    exit;
	}
    //$advt_id = $_SESSION['ad_id'];
    $advt_id_num = intval($advt_id);
    $query = "UPDATE advertisement_table SET buyer_id = '$buyer_id'  WHERE ad_id = '$advt_id_num' and owner_id = '$user_id'";
    $insert="UPDATE advertisement_table Set date_of_purchase='$today' where ad_id = '$advt_id_num' and owner_id = '$user_id'";
    $result = mysqli_query($db,$query);
    $result1=mysqli_query($db,$insert);
    
    if($result and $result1){
       echo "<script type='text/javascript'>alert('Updated Succesfully')</script>";	
       header('refresh:2; url:http://localhost/Myproject/Set_buyer.php');
    }
    else{
    	echo "<script type='text/javascript'>alert('Failed! Try again')</script>";
      exit;
    }
    
}

?>