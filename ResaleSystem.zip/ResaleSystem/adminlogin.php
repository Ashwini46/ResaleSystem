<?php  
require 'config/config.php';
?>


<head>
 <meta charset="utf-8">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="css/Global.css">
</head>
<body style="background-image: url('./wallimg/fullscreenblue.svg');
  background-repeat:no-repeat; background-size:100%;">

  <!--<header class="login_h">
  <h2>Rent IT On<h2>
</header>-->
<div class="container-fluid bg">

	<div class="row">
    	<div class="col-md-6 col-sm-6 col-xs-12" style="background-image: url('./wallimg/ad1.jpg');background-repeat: no-repeat;height: 100%;background-color:white;font-family: 'Times New Roman', Times, serif;">
      <div class="content" style="align-item:center;text-align: center; margin-top:500px">
        <h3 style="color:white;line-height: 1.6;font-family:'Lucida Handwriting'">
        "A small business is an amazing way to serve and leave an impact on the world you live in.”
        </h3>
        <h2 style="color:white;text-align: center;font-family:'Georgia'">
         -Nicole Snow
        </h2>
      </div>
    </div>
		<div class="col-md-4 col-sm-4 col-xs-12"></div>
		<div class="col-md-4 col-sm-4 col-xs-12">
			<!--form start-->
      <br>
      <br><br>
<form action='adminlogin.php' method="post" class="form-container" style="background-color:white;margin-left:80px">
<br><br>
<img src="pic/avatar.png" class="avatar" style="margin-left:25%">
<div style="margin-top:-35px">
      <h1 >Admin Login</h1>
      <div class="form-group">
        <label  for="exampleInputEmail1">Email address</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
      </div>
    
      <br>
      <input type="submit" id="submit" name="submit" value="Submit" class="btn btn-success btn-block">
      <br>
      <p style="font-size:18px;font-weight:bolder">Login as User<a href="login.php"style="text-decoration: none;font-size:14px;" >&nbsp&nbsp&nbsp User Login </a></p>
    </form>
</div>
            <!--form ends-->
		</div>
        <div class="col-md-4 col-sm-4 col-xs-12"></div>
	</div>
</div>

<?php
    $servername = "localhost";
    $dbuser = "root";
    $dbpassword = "";
    $dbname="myproject";
    //connection 
    $db =mysqli_connect($servername,$dbuser,$dbpassword,$dbname);
   if(isset($_POST['submit'])){
     $email_address = ($_POST['email']);
     $password = trim($_POST['password']);
     
     $email_address=stripcslashes($email_address);
     $password=stripcslashes($password);
     $email_address=mysqli_real_escape_string($db,$email_address);
     $password = mysqli_real_escape_string($db, $password); 
     $query = "SELECT * FROM `adminlogin` WHERE admin_email = '$email_address' AND password='$password'";
     $result = mysqli_query($db,$query);

     if(mysqli_num_rows($result)==1){
           $_SESSION['email'] = $email_address;
           $_SESSION['password']=$password;
           $_SESSION['success'] = "You are now logged in";
           header('location: admin.php');
     }
     else{
           echo "<script type='text/javascript'>alert('Failed to Login! Incorrect Email or Password')</script>";
     }
   }
?>
