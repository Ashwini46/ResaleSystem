<?php
require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Website Title</title>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  .color-white{
    color: white;
  }
  .form-control{
    border:1px solid black;
    width:400px;
  }
  
  
</style>
<body style="background-size:100%;background-color:white">

<!--	<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Top navigation -->
<div class="topnav" style="background-color:#0099ff;margin-left:1px">

  <!-- Left-aligned links (default) -->
  <a href="Laptop_Mobile.php">Mobiles & Computers</a>
  <a href="Electronics.php">Electronics</a>
  <a href="Furniture.php">Furnitures</a>
  <div class="topnav-right">
    
  </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12" style="background-image: url('./wallimg/lap3.jpeg');background-repeat: no-repeat;max-height: 100%;max-width:100%;display: block; object-fit: fill;background-color:white;font-family: 'Times New Roman', Times, serif;">
      <div class="content" style="align-item:center;text-align: center; margin-top:500px">
        <h3 style="color:white;line-height: 1.6;font-family:'Lucida Handwriting'">
        "Your phone needs to recharge every night. Your laptop needs to recharge. Everything needs to recharge. Are you giving yourself space, time and effort to recharge?”
        </h3>
      </div>
    </div>
	<div class="container" style="margin-left:175px">
  
  <!---------------------------------------------------------------->
  <form class="form-horizontal" action="Laptop_Mobile.php" method="POST" style="background-color:white;margin-left:400px;margin-right:100px;height:600px;width:740px;" enctype="multipart/form-data">
  <h2 class="color-black" style="margin-left:100px;margin-top:20px;text-align:center">Post an Advertisement</h2><br>
   <!---------------------------------------------------------------->
    <div class="form-group" style="padding-top:10px;">
      <label class="control-label col-sm-2 color-black" for="product_name" >Product Name</label>
      <div class="col-sm-5">
      <select name="product_name" class="form-control" id="product_name" placeholder="-----------------Select-----------------" require>
      <option value>----------------------------------------Select----------------------------------------</option>
      <?php 

      $sql="SELECT DISTINCT(item_name) from admin where item_type='Laptop_mobile'";
      $res=mysqli_query($db,$sql);
      while($row=mysqli_fetch_assoc($res)){
        
      echo "<option value='".$row['item_name']."'>" .$row['item_name']."</option>";    
    }?>
      </select>
      </div>
    </div>
    <div class="form-group" style="margin-top:-530px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="manufacturer">Manufacturer</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control" id="manufacturer" placeholder="Manufacturer" name="manufacturer" required>
      </div>
    </div>
    <div class="form-group" style="margin-top:-475px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="model_name">Model Name</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="model_name" placeholder="Model Name" name="model_name" required>
      </div>
    </div>
    <div class="form-group"style="margin-top:-420px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="yop">Year of Purchase</label>
      <div class="col-sm-10">          
        <input type="number" class="form-control" id="yop" placeholder="Year of Purchase" name="yop" required min='1980' max='2021'>
      </div>
    </div>
    <div class="form-group" style="margin-top:-365px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="battery_status">Battery Status</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="battery_status" placeholder="Battery Status" name="battery_status" required>
      </div>
    </div>
    <div class="form-group"style="margin-top:-310px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="description">Ad description</label>
      <div class="col-sm-10">          
        <textarea class="form-control" id="description" placeholder="Ad description" name="description"></textarea>  
      </div>
    </div>
    <div class="form-group"style="margin-top:-235px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="expected_price">Expected Price</label>
      <div class="col-sm-10">          
        <input type="number" class="form-control" id="expected_price" placeholder="Expected Price" name="expected_price" min=100 required>
      </div>
      </div>
      <!---------------------------------------------------------------------------------------------------------->
      <div class="form-group" style="margin-top:-180px;margin-left:106px">
      <label class="control-label col-sm-2 color-black" for="upload_img">Upload Image</label>
      <div class="col-sm-10">          
      <input type="file" id="file" value="" class="form-control" name="fileUpload[]" multiple="multiple" >
      </div>
    </div>
   
    <div class="form-group" style="margin-top:-100px;margin-left:100px">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" id="submit" name="submit" class="btn btn-primary" style="width:300px;margin-top:10px;margin-left:50px" onclick="window.location.href='./Laptop_Mobile.php';">Submit</button>
      </div>
    </div>
  </form>
</div>



<?php
    $db = mysqli_connect("localhost", "root","", "myproject"); 
    $owner_email=$_SESSION['email'];
    $today =  Date("Y-m-d");
    $expiry = Date("Y-m-d",strtotime("+10 days"));

    if(isset($_POST["submit"]))
{
    $productName = $_POST['product_name'];
    $manufacturer = $_POST['manufacturer'];
    $modelName = $_POST['model_name'];
    $yearOfPurchase = $_POST['yop'];
    $batteryStatus = $_POST['battery_status'];
    $ad_description = $_POST['description'];
    $expectedPrice = $_POST['expected_price'];
    $laptop="Laptop_mobile";
    $uploadsDir = "upload/";
    $allowedFileType = array('jpg','png','jpeg');

    if (!empty(array_filter($_FILES['fileUpload']['name']))) {
          foreach($_FILES['fileUpload']['name'] as $ad_id=>$val)
          {
            $fileName        = $_FILES['fileUpload']['name'][$ad_id];
            $tempLocation    = $_FILES['fileUpload']['tmp_name'][$ad_id];
            $targetFilePath  = $uploadsDir . $fileName;
            $fileType        = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            if(in_array($fileType,$allowedFileType))
            {
              if(move_uploaded_file($tempLocation,$targetFilePath))
              {
                $sqlval="('".$fileName."')";
              }else{
                $respose=array("status"=>"alter-danger","message"=>"File Could not be uploade");
              }
            }else{
              $respose=array("status"=>"alter-danger","message"=>"File Format not allowed");
            }
              
          
  
    if(!empty($sqlval))
    { 
    $sql1="INSERT INTO advertisement_table (item_name,item_type,date_of_init,date_of_exp,owner_id,upload_img) VALUES ('$productName','$laptop','$today','$expiry','$owner_email','$fileName')";
    $result1=mysqli_query($db,$sql1);

    #echo "<script type='text/javascript'>alert('Trying to accesss advirtisment table')</script>";

    if($result1)
    {
      #insert
      $sql3="SELECT ad_id from advertisement_table  where item_name='$productName' and owner_id='$owner_email'";
      $result2=mysqli_query($db,$sql3);
      $row=mysqli_fetch_assoc($result2);
      $temp=$row["ad_id"];
      echo $temp;
      
      $sql2="INSERT INTO laptop_mobile (product_id,product_name,manufacturer,model_name,year_of_purchase,battery_status,ad_descripation,expected_price,upload_img) VALUES ('$temp','$productName','$manufacturer','$modelName','$yearOfPurchase','$batteryStatus','$ad_description','$expectedPrice','$fileName')";       
      echo $sql2;     
      $result3=mysqli_query($db,$sql2); 
      echo $result3;                                                                                                                            
      echo "<script type='text/javascript'>alert('Advertisement Posted Successfully')</script>";
    }
  }
}
}
}
	?>
</body>
</html>