-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 07:49 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `electronics`
--

CREATE TABLE `electronics` (
  `prod_id` int(100) NOT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `manufacturer` varchar(220) DEFAULT NULL,
  `model_name` varchar(220) DEFAULT NULL,
  `year_of_purchase` int(220) DEFAULT NULL,
  `ad_description` varchar(220) DEFAULT NULL,
  `expected_price` int(220) DEFAULT NULL,
  `upload_img` varchar(220) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electronics`
--

INSERT INTO `electronics` (`prod_id`, `product_name`, `manufacturer`, `model_name`, `year_of_purchase`, `ad_description`, `expected_price`, `upload_img`) VALUES
(3, 'TV', 'LG', '43UN7300PTC UHD LED', 2019, 'AI ThinQ™ w/ Built-in Google Assistant & Alexa, Apple Airplay 2 & Homekit\r\nFilmmaker Mode, HDR 10 Pro & HLG Pro\r\nGaming: Low Input Lag & HGiG Profile\r\nSports Alert & Bluetooth Surround Ready\r\nWebOS w/ Unlimited OTT App S', 17000, 'teknas-24-led_1.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `electronics`
--
ALTER TABLE `electronics`
  ADD PRIMARY KEY (`prod_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
