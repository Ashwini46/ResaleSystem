-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 07:48 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisement_table`
--

CREATE TABLE `advertisement_table` (
  `ad_id` int(100) NOT NULL,
  `item_name` text DEFAULT NULL,
  `item_type` text DEFAULT NULL,
  `date_of_init` date DEFAULT NULL,
  `date_of_exp` date DEFAULT NULL,
  `owner_id` varchar(250) DEFAULT NULL,
  `buyer_id` varchar(250) DEFAULT NULL,
  `upload_img` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisement_table`
--

INSERT INTO `advertisement_table` (`ad_id`, `item_name`, `item_type`, `date_of_init`, `date_of_exp`, `owner_id`, `buyer_id`, `upload_img`) VALUES
(1, 'Laptop', 'Laptop_mobile', '2021-01-13', '2021-01-23', 'ashwinipapu4@gmail.com', '', 'laptop_hp.jpg'),
(2, 'Dining Suites', 'Furnitutre', '2021-01-15', '2021-01-25', 'ashwinipapu4@gmail.com', 'bhargavraj4@gmail.com', 'unnamed.jpg'),
(3, 'TV', 'Elecronics', '2021-01-15', '2021-01-25', 'ashwinipapu4@gmail.com', NULL, 'teknas-24-led_1.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisement_table`
--
ALTER TABLE `advertisement_table`
  ADD PRIMARY KEY (`ad_id`),
  ADD UNIQUE KEY `owner_id` (`owner_id`,`buyer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisement_table`
--
ALTER TABLE `advertisement_table`
  MODIFY `ad_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
