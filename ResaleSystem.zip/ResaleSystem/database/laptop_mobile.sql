-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 07:49 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `laptop_mobile`
--

CREATE TABLE `laptop_mobile` (
  `product_id` int(100) NOT NULL,
  `product_name` varchar(220) NOT NULL,
  `manufacturer` varchar(220) DEFAULT NULL,
  `model_name` varchar(220) DEFAULT NULL,
  `year_of_purchase` int(220) DEFAULT NULL,
  `battery_status` varchar(225) DEFAULT NULL,
  `ad_descripation` varchar(225) DEFAULT NULL,
  `expected_price` varchar(255) DEFAULT NULL,
  `upload_img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `laptop_mobile`
--

INSERT INTO `laptop_mobile` (`product_id`, `product_name`, `manufacturer`, `model_name`, `year_of_purchase`, `battery_status`, `ad_descripation`, `expected_price`, `upload_img`) VALUES
(1, 'Laptop', 'DELL', 'ip7', 2018, '6hrs', 'good in working condition', '25000', 'laptop_hp.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `laptop_mobile`
--
ALTER TABLE `laptop_mobile`
  ADD PRIMARY KEY (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
