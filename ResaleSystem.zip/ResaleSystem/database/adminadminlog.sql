-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2021 at 02:41 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `item_type` varchar(250) NOT NULL,
  `item_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `item_type`, `item_name`) VALUES
(1, 'Laptop_mobile', 'Tab'),
(4, 'Laptop_mobile', 'Mobile'),
(5, 'Laptop_mobile', 'Laptop'),
(7, 'Elecronics', 'TV'),
(8, 'Elecronics', 'Fridge'),
(9, 'Elecronics', 'Washing Machine'),
(10, 'Elecronics', 'Microwave'),
(11, 'Elecronics', 'Electric Stove'),
(12, 'Elecronics', 'Mixer'),
(13, 'Furnitutre', 'Sofa'),
(14, 'Furnitutre', 'Wardrobes'),
(15, 'Furnitutre', 'Cupboards'),
(16, 'Furnitutre', 'Study Table'),
(17, 'Furnitutre', 'Dining Suites'),
(18, 'Laptop_mobile', 'Desk Top'),
(19, 'Elecronics', 'Fan'),
(20, 'Laptop_mobile', 'Pen Drive'),
(21, 'Elecronics', 'Blender'),
(22, 'Elecronics', 'Air Conditioner'),
(23, 'Furnitutre', 'Cot'),
(24, 'Elecronics', 'Speaker'),
(26, 'Furnitutre', 'Chair'),
(27, 'Furnitutre', 'Chair'),
(30, 'Laptop_mobile', 'Laptop'),
(31, 'Laptop_mobile', 'Laptop'),
(32, 'Furnitutre', 'sofa'),
(33, 'Furnitutre', 'Sofa'),
(34, 'Laptop_mobile', 'Laptop'),
(35, 'Laptop_mobile', 'Laptop');

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `id` int(100) NOT NULL,
  `admin_email` varchar(250) NOT NULL,
  `admin_name` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `admin_email`, `admin_name`, `password`) VALUES
(1, 'admin123@adsel.com', 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement_table`
--

CREATE TABLE `advertisement_table` (
  `ad_id` int(100) NOT NULL,
  `item_name` text DEFAULT NULL,
  `item_type` text DEFAULT NULL,
  `date_of_init` date DEFAULT NULL,
  `date_of_exp` date DEFAULT NULL,
  `owner_id` varchar(250) DEFAULT NULL,
  `buyer_id` varchar(250) DEFAULT NULL,
  `date_of_purchase` varchar(50) DEFAULT NULL,
  `upload_img` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisement_table`
--

INSERT INTO `advertisement_table` (`ad_id`, `item_name`, `item_type`, `date_of_init`, `date_of_exp`, `owner_id`, `buyer_id`, `date_of_purchase`, `upload_img`) VALUES
(1, 'Laptop', 'Laptop_mobile', '2021-02-18', '2021-02-28', 'ashwinipapu4@gmail.com', 'bhargavraj4@gmail.com', '23/02/2021', 'hp-laptop-500x500.jpg'),
(2, 'Sofa', 'Furnitutre', '2021-02-18', '2021-02-28', 'ashwinipapu4@gmail.com', 'arpitha@gmail.com', '2021-02-23', 'sofa.jpg'),
(3, 'Wardrobes', 'Furnitutre', '2021-02-18', '2021-02-28', 'bhargavraj4@gmail.com', 'ashwinipapu4@gmail.com', '2021-02-23', 'cubboard.jpg'),
(4, 'TV', 'Elecronics', '2021-02-18', '2021-02-28', 'bhargavraj4@gmail.com', NULL, NULL, 'teknas-24-led_1.png'),
(5, 'Microwave', 'Elecronics', '2021-02-18', '2021-02-28', 'bhargavraj4@gmail.com', NULL, NULL, 'images.jpg'),
(6, 'Electric Stove', 'Elecronics', '2021-02-22', '2021-03-04', 'mary2611@gmail.com', NULL, NULL, 'induction.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `electronics`
--

CREATE TABLE `electronics` (
  `prod_id` int(100) NOT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `manufacturer` varchar(220) DEFAULT NULL,
  `model_name` varchar(220) DEFAULT NULL,
  `year_of_purchase` int(220) DEFAULT NULL,
  `ad_description` varchar(220) DEFAULT NULL,
  `expected_price` int(220) DEFAULT NULL,
  `upload_img` varchar(220) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `electronics`
--

INSERT INTO `electronics` (`prod_id`, `product_name`, `manufacturer`, `model_name`, `year_of_purchase`, `ad_description`, `expected_price`, `upload_img`) VALUES
(4, 'TV', 'Teknas', '2017', 2019, '24 Inch LED HD TV', 12000, 'teknas-24-led_1.png'),
(5, 'Microwave', 'samsung', 'i360', 2018, 'good for family of 4 ', 25000, 'images.jpg'),
(6, 'Electric Stove', 'Prestige', 'Induction Cooktop PIC 22.0', 2019, '    Body material: polypropylene\r\n    Power: 1200 Watts\r\n    Anti magnetic wall\r\n    Cord length - 4.25 ft.\r\n    Warranty: 1 year warranty\r\n    Push Button Controls', 1000, 'induction.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `furniture`
--

CREATE TABLE `furniture` (
  `product_id` int(100) NOT NULL,
  `product_name` text DEFAULT NULL,
  `year_of_purchase` int(11) DEFAULT NULL,
  `condition_pro` text DEFAULT NULL,
  `ad_descripation` varchar(250) DEFAULT NULL,
  `expected_price` int(250) DEFAULT NULL,
  `upload_img` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `furniture`
--

INSERT INTO `furniture` (`product_id`, `product_name`, `year_of_purchase`, `condition_pro`, `ad_descripation`, `expected_price`, `upload_img`) VALUES
(2, 'Sofa', 2018, 'Very Good', 'Gray Leather sofa with 14X8 feet Long Best fit for living room', 5000, 'sofa.jpg'),
(3, 'Wardrobes', 2017, 'Good', 'Single door cupboard with multiple drawers', 12000, 'cubboard.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `laptop_mobile`
--

CREATE TABLE `laptop_mobile` (
  `product_id` int(100) NOT NULL,
  `product_name` varchar(220) NOT NULL,
  `manufacturer` varchar(220) DEFAULT NULL,
  `model_name` varchar(220) DEFAULT NULL,
  `year_of_purchase` int(220) DEFAULT NULL,
  `battery_status` varchar(225) DEFAULT NULL,
  `ad_descripation` varchar(225) DEFAULT NULL,
  `expected_price` varchar(255) DEFAULT NULL,
  `upload_img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `laptop_mobile`
--

INSERT INTO `laptop_mobile` (`product_id`, `product_name`, `manufacturer`, `model_name`, `year_of_purchase`, `battery_status`, `ad_descripation`, `expected_price`, `upload_img`) VALUES
(1, 'Laptop', 'HP', 'hpi768', 2019, '19hrz', 'Black Slim Laptop with Intel 3 Processor Ram 1Tb', '48000', 'hp-laptop-500x500.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(100) NOT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `receiver_id` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `msg_date` varchar(255) DEFAULT NULL,
  `msg_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `sender_id`, `receiver_id`, `message`, `msg_date`, `msg_time`) VALUES
(3, 'bhargavraj4@gmail.com', 'ashwinipapu4@gmail.com', 'Hi!', '2021-02-18', '02:58:15'),
(4, 'ashwinipapu4@gmail.com', 'bhargavraj4@gmail.com', 'hi', '2021-02-19', '10:39:50'),
(5, 'bhargavraj4@gmail.com', 'ashwinipapu4@gmail.com', 'hi I would Like to buy your product', '2021-02-19', '10:45:40'),
(6, 'bhargavraj4@gmail.com', 'ashwinipapu4@gmail.com', 'Can we discus about price', '2021-02-19', '11:01:27'),
(8, 'arpitha@gmail.com', 'bhargavraj4@gmail.com', 'hi', '2021-02-19', '11:51:41'),
(9, 'bhargavraj4@gmail.com', 'arpitha@gmail.com', 'hi', '2021-02-19', '11:52:31'),
(10, 'mary2611@gmail.com', 'ashwinipapu4@gmail.com', 'Hi Ashwini I would like to ask you about your product', '2021-02-22', '11:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Nitc_email_id` varchar(255) NOT NULL,
  `User_name` varchar(255) DEFAULT NULL,
  `Mobile_no` varchar(255) DEFAULT NULL,
  `User_password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Nitc_email_id`, `User_name`, `Mobile_no`, `User_password`) VALUES
('arpitha@gmail.com', 'Arpitha', '9343382024', 'Arpitha123'),
('ashwinipapu4@gmail.com', 'Ashwini', '9741477157', '123'),
('bhargavraj4@gmail.com', 'Bhargav Raj', '9483305080', 'Raj123'),
('mary2611@gmail.com', 'Mary', '9536842592', 'Mary2611');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisement_table`
--
ALTER TABLE `advertisement_table`
  ADD PRIMARY KEY (`ad_id`),
  ADD UNIQUE KEY `owner_id` (`owner_id`,`buyer_id`);

--
-- Indexes for table `electronics`
--
ALTER TABLE `electronics`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `furniture`
--
ALTER TABLE `furniture`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `laptop_mobile`
--
ALTER TABLE `laptop_mobile`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Nitc_email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `advertisement_table`
--
ALTER TABLE `advertisement_table`
  MODIFY `ad_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `Messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`Nitc_email_id`),
  ADD CONSTRAINT `Messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`Nitc_email_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
