-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 07:50 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(100) NOT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `receiver_id` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `msg_date` varchar(255) DEFAULT NULL,
  `msg_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `sender_id`, `receiver_id`, `message`, `msg_date`, `msg_time`) VALUES
(1, 'kenil@gmail.com', 'praj12121998@gmail.com', 'This is Kenil Shah. I would like to buy your iPhone 10.', '2018-10-09', '03:14 AM'),
(2, 'kenil@gmail.com', 'praj12121998@gmail.com', 'But The price is too much can you reduce it to 55000', '2018-10-09', '03:15 AM'),
(3, 'praj12121998@gmail.com', 'kenil@gmail.com', 'Sorry I can\'t agree for 55000 but I can agree for 57000 ', '2018-10-09', '03:17 AM'),
(4, 'praj12121998@gmail.com', 'kenil@gmail.com', 'Please tell me quickly otherwise it will be sold to another person ', '2018-10-09', '03:19 AM'),
(5, 'praj12121998@gmail.com', 'kenil@gmail.com', 'Hi this is mwee', '2018-10-09', '03:59 AM'),
(6, 'ashwinipapu4@gmail.com', 'praj12121998@gmail.com', 'hiiii', '2021-01-06', '02:11 PM'),
(7, 'praj12121998@gmail.com', 'ashwinipapu4@gmail.com', 'hii', '2021-01-06', '02:15 PM'),
(8, 'vinod@gmail.com', 'surabh@gmail.com', 'I would like to buy your mobile phone', '2021-01-11', '06:19 AM'),
(9, 'vinod@gmail.com', 'surabh@gmail.com', 'can i get it for Rs 6000', '2021-01-11', '06:20 AM'),
(10, 'surabh@gmail.com', 'vinod@gmail.com', 'No i am not ready to sell it for so low price\r\n', '2021-01-11', '06:25 AM'),
(11, 'bhargavraj4@gmail.com', 'ashwinipapu4@gmail.com', 'i Would like to Buy your dining table ', '2021-01-15', '07:05 AM'),
(16, 'ashwinipapu4@gmail.com', 'bhargavraj4@gmail.com', 'Ok', '2021-01-15', '12:13:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `Messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`Nitc_email_id`),
  ADD CONSTRAINT `Messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`Nitc_email_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
