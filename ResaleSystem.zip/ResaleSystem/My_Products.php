<?php 
   require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>My Products</title>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>	
  <link rel="stylesheet" type="text/css" href="css/advertise.css">
	<link rel="stylesheet" type="text/css" href="css/purchase.css">
</head>
<style type="text/css">
  footer{
    position: absolute;
    bottom: 0;
    width: 100%;
    color:black;
  }
    .container{
      font-size:15px;
      background-color: transperent;
    }
  
</style>
<script type="text/javascript">
    window.history.forward();
    function noBack()
    {
        window.history.forward();
    }
</script>
<body style="background-image: url('./wallimg/benefits-bg.svg');background-color:white;
  background-repeat:repeat ; background-size:100%; position:absolute;" onLoad="noBack();" onpageshow="if (event.persisted) noBack();" onUnload="">

 
	<!--<nav class="navbar navbar-inverse">-->
  <div class="container">

    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="background-color:white;margin-left:200px;margin-right:-90px">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php" class="l1 active" >HOME</a></li>
        <li><a href="Purchase.php" class="l1">ALL PRODUCT</a></li>
        <li><a href="Laptop_Mobile.php "class="l1">ADVERTISE</a></li>
        <li><a href="bought_products.php"class="l1">BOUGHT PRODUCTS</a></li>
        <li><a href="message.php"class="l1">MESSAGES</a></li>
        <li><a href="about_us.php"class="l1">ABOUT US</a></li>
        <li class="dropdown"><a href="my_products.php" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div>
  <div>
    <h1 style="text-align:center;margin-top:30px;text-decoration: underline;font-family:Georgia">Your Product</h1>
  </div>
</div>
<br><br><br>
<?php
$help=array();
$user_id = $_SESSION['email'];
$query = "SELECT * FROM advertisement_table where owner_id = '$user_id'";
$result = mysqli_query($db,$query);
if(mysqli_num_rows($result) == 0){
  echo "<script type='text/javascript'>alert('You have not Advertised any Yet! Product click ok to Adverstise your product')</script>";
  echo "<script> location ='http://localhost/myProject/Advertise.php'</script>";
}
#echo "<script type='text/javascript'>alert('You have  Advertised some Product')</script>";
while($row=mysqli_fetch_assoc($result))
  {
    $id=$row["ad_id"];
    $email_id=$row["owner_id"];
    $image=["upload_img"];

    $sqll="SELECT DISTINCT product_name FROM laptop_mobile where product_id='$id' ";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
   #echo "<script type='text/javascript'>alert('Something is working')</script>" ;
      $sql2="SELECT * FROM laptop_mobile where product_id='$id'";
      $result2=mysqli_query($db,$sql2);
      $row2=mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";
      $lapid=$row2["product_id"];
      #echo "<script type='text/javascript'>alert('Select from laptop_mobile')</script>" ;
      $sql3="SELECT * FROM users WHERE Nitc_email_id = '$email_id'";
      $result3=mysqli_query($db,$sql3);
      $row3=mysqli_fetch_assoc($result3);
      ?>
      
      <div class="container">
      <?php
    
      if(isset($_GET['delete']))
      {
       
        $delid=$_GET['delete'];
        $data=mysqli_query($db,"DELETE FROM advertisement_table where ad_id='$delid' ");
        $del=mysqli_query($db,"DELETE FROM laptop_mobile where product_id ='$delid' "); 
        echo $row["ad_id"];
        //$data=mysqli_query($db,$delqury);
        if($data)
        {
          echo "<script type='text/javascript'>alert('Product deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
        else{
          echo "<script type='text/javascript'>alert('Record not deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
      }
    ?>
            <div class="row row-margin-bottom">
             <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                                <b><?php echo $row["item_name"]; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-data">
                            <p>Advt ID: <b><?php echo $row["ad_id"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Manufacturer: <b><?php echo $row2["manufacturer"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Model Name: <b><?php echo $row2["model_name"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Year Of Purchase: <b><?php echo $row2["year_of_purchase"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Battery Status: <b><?php echo $row2["battery_status"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-desc">
                                <p> Ad Description: <b><?php echo $row2["ad_descripation"]; ?></b> </p>
                                <hr>
                            </div>
                            <div class="lib-row lib-price">
                              <p>Expected Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
                            <input type="hidden" name="id" value="4">
                            <div class="lib-row lib-data">
                              <p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>
                            <?php
                               if ($row["buyer_id"]) {
                               	?>
                             <div class="lib-row lib-data">
                              <p style="color: red;">SOLD TO: <b><?php echo $row["buyer_id"];?></b></p>
                            </div>
                            
                            <?php 
                               }
                            ?>
                            <a href="My_Products.php?delete=<?php echo $lapid;?>">
                            <centre><button style="width: 100px; height:40px; margin-bottom:10px;margin-left:250px; border-radius: 2px;font-size:15px;padding: 10px 10px;" type="submit" id="delete" name="delete" class="btn btn-danger" >DELETE</button></centre></a>
                        </div>	
                    </div>
                </div>
            </div>
            
        
</div>

<?php
    }
    $help=array();
    $sqll="SELECT DISTINCT product_name FROM electronics where prod_id='$id'";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
      $sql2="SELECT * FROM electronics where prod_id='$id'";
      $result2=mysqli_query($db,$sql2);
      #echo "<script type='text/javascript'>alert('Executing if')</script>" ;
      $row2=mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";
      $eleid=$row2['prod_id'];
      $sql3="SELECT * FROM users WHERE Nitc_email_id = '$email_id'";
      $result3=mysqli_query($db,$sql3);
      $row3=mysqli_fetch_assoc($result3);
      ?>

        <div class="container">
        <?php
      if($u=isset($_GET['delete']))
      {
        $delid=$_GET['delete'];
        $data=mysqli_query($db,"DELETE FROM advertisement_table where ad_id='$delid' ");
        $del=mysqli_query($db,"DELETE FROM electronics where prod_id ='$delid' ");
        echo $row["ad_id"];
        //$data=mysqli_query($db,$delqury);
        if($data)
        {
          echo "<script type='text/javascript'>alert('Product deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
        else{
          echo "<script type='text/javascript'>alert('Record not deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
      }
    ?>
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                               <b> <?php echo $row["item_name"]; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-data">
                            <p>Advt ID: <b><?php echo $row["ad_id"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Manufacturer: <b><?php echo $row2["manufacturer"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Model Name: <b><?php echo $row2["model_name"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Year Of Purchase: <b><?php echo $row2["year_of_purchase"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-desc">
                                <p> Ad Description: <b><?php echo $row2["ad_description"]; ?></b> </p>
                                <hr>
                            </div>
                            <div class="lib-row lib-price">
                              <p>Expected Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Contact Details: <b><?php echo $row3["User_name"]." Mobile No: ".$row3["Mobile_no"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>
                            <?php
                               if ($row["buyer_id"]) {
                               	?>
                             <div class="lib-row lib-data">
                              <p style="color: red;">SOLD TO: <b><?php echo $row["buyer_id"];?></b></p>
                            </div>                            
                            <?php 
                               }
                            ?>
                            <a href="My_Products.php?delete=<?php echo $eleid;?>">
                            <centre><button style="width: 100px; height:40px; margin-bottom:10px;margin-left:250px; border-radius: 2px;font-size:15px;padding: 10px 10px;" type="submit" id="delete" name="delete" class="btn btn-danger" >DELETE </button></centre></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
            <!--<?php $_SESSION['ad_id']=$id; ?>-->
            <!--<a href="set_buyer.php?id=<?php echo $row["advt_id"]; ?>"><button type="submit" id="sold" name="sold" class="btn btn-primary">SOLD</button></a>-->

        </div>
</div>  
<?php
    }


    $help=array();
    $sqll="SELECT DISTINCT product_name FROM furniture where product_id = '$id'";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
      #echo "<script type='text/javascript'>alert('Something is working')</script>" ;
      
      $query2 = "SELECT * FROM furniture WHERE product_id = '$id'";
    	$result2 = mysqli_query($db,$query2);
    	$row2 = mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";
      $funid=$row2['product_id'];

    	$query3 = "SELECT * FROM Users WHERE Nitc_email_id = '$email_id'";
    	$result3 = mysqli_query($db,$query3);
      $row3 = mysqli_fetch_assoc($result3);
      ?>
    <div class="container">
    <?php
    
      if(isset($_GET['delete']))
      {
       
        $delid=$_GET['delete'];
        $data=mysqli_query($db,"DELETE FROM advertisement_table where ad_id='$delid' ");
        $del=mysqli_query($db,"DELETE FROM furniture where product_id ='$delid' ");
        //echo $row["ad_id"];
        //$data=mysqli_query($db,$delqury);
        if($data)
        {
          echo "<script type='text/javascript'>alert('Product deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
        else{
          echo "<script type='text/javascript'>alert('Record not deleted');window.location.reload();</script>";
          header('location:my_products.php');
        }
      }
    ?>
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                        <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                                <b><?php echo $item_name; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-data">
                            <p>Advt ID: <b><?php echo $row["ad_id"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-header">
                            	<p>Name of Furniture: <b><?php echo $row2["product_name"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Year Of Purchase: <b><?php echo $row2["year_of_purchase"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Condition: <b><?php echo $row2["condition_pro"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-desc">
                                <p> Ad Description: <b><?php echo $row2["ad_descripation"]; ?> </b></p>
                                <hr>
                            </div>
                            <div class="lib-row lib-price">
                            	<p>Expected Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Contact Details: <b><?php echo $row3["User_name"]." ".$row3["Mobile_no"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>
                            <?php
                               if ($row["buyer_id"]) {
                               	?>
                             <div class="lib-row lib-data">
                              <p style="color: red;">SOLD TO: <b><?php echo $row["buyer_id"];?></b></p>
                            </div>
                            
                            <?php 
                               }
                            ?>
                            <a href="My_Products.php?delete=<?php echo $funid;?>">
                            <centre><button style="width: 100px; height:40px; margin-bottom:10px;margin-left:250px; border-radius: 2px;font-size:15px;padding: 10px 10px;" type="submit" id="delete" name="delete" class="btn btn-danger" >DELETE </button></centre></a>
                           
                          </div>
                    </div>
                </div>
                
            </div>
            <!--<div class="col-md-1"></div>-->
            <!--<?php $_SESSION['ad_id']=$id; ?>-->
           <!--<a href="set_buyer.php?id=<?php echo $row["advt_id"]; ?>"><button type="submit" id="sold" name="sold" class="btn btn-primary">SOLD</button></a>-->


        </div>
</div>  
      
 <?php  
    }
  }
  ?>
   <br>	
 <br>
<br>
<br>
<br>
<br>
 <a href="set_buyer.php"><centre><button style="width: 50%; height:500%; margin-left:300px; border-radius: 2px;font-size:15px;padding: 20px 10px;" type="submit" id="sold" name="sold" class="btn btn-primary" >CLICK TO SELL ITEMS</button></centre></a>	
 <br>	
 <br>
<br>
<br>
<br>
<br>
</footer>
<div Style="background-color:white;width:1418px;margin-left:-110px;margin-bottom:-95px">
  <p align='center' style="background-color:white;height:50px;padding-top:15px;padding-left:35%;width:1000px">@ 2021 Copyright <a href="home_2.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
  </div>



