<?php 
   require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>My Products</title>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>	
  <link rel="stylesheet" type="text/css" href="css/advertise.css">
	<link rel="stylesheet" type="text/css" href="css/purchase.css">
  
</head>
<style type="text/css">
  footer{
    position: absolute;
    bottom: 0;
    width: 100%;
    background-color:white;
    
  }
  .container{
    margin-left:70px;
    
  }

  .lib-img-show{
  background-color:lightpink;
 }
</style>
<body style="background-image: url('./wallimg/benefits-bg.svg');background-color:white;
  background-repeat:repeat ; background-size:100%; position:absolute;">

 
<!--	<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>
  
 
    </div>

    <div class="collapse navbar-collapse" id="myNavbar">
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="Purchase.php">ALL PRODUCT</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="./Laptop_Mobile.php">ADVERTISE</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
    
  </div>
  <br><br><br>


<?php
$user_id = $_SESSION['email'];
$query = "SELECT * FROM advertisement_table where buyer_id = '$user_id'";
$result = mysqli_query($db,$query);

if(mysqli_num_rows($result) == 0){

  ?>
  
  <div class="container">
  <br><br><br><br>
    <h1 align="center" style="Margin-left:100px; font-family: 'Times New Roman', Times, serif;"> HAVE NOT BOUGHT ANY PRODUCT YET!!</h1> 
 
  <br><br><br><br><br>
  <input type="button" id="submit" name="submit" value="CLICK TO VIEW ITEMS" class="btn btn-primary" onclick="window.location.href='http://localhost/Myproject/Purchase.php';" align="center" style="width: 70%; margin-left:200px;">
  <br>
  
            <!--form ends-->
	
        <div class="col-md-4 col-sm-4 col-xs-12"></div>
  </div>
<br><br><br><br><br><br><br><br><br><br><br><br><br>  
<?php
}

while ($row = mysqli_fetch_assoc($result)) {
    //echo $row["item_name"];
    //echo $row["date_of_init"];
    //echo $row["date_of_exp"];
    //echo '<br>';
    $id = $row["ad_id"];
    $email_id = $row["owner_id"];
    $q=$row['date_of_purchase'];
    
    $help=array();
    $sqll="SELECT DISTINCT product_name FROM laptop_mobile where product_id='$id' ";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
      $query2 = "SELECT * FROM Laptop_mobile WHERE product_id = '$id'";
      $result2 = mysqli_query($db,$query2);
      $row2 = mysqli_fetch_assoc($result2);
        

      $query3 = "SELECT * FROM users WHERE Nitc_email_id = '$email_id'";
      $result3 = mysqli_query($db,$query3);
      $row3 = mysqli_fetch_assoc($result3); 
       ?>
      
      <div class="container">
        
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">

                        <div class="col-md-6">
                            <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">

                            <div class="lib-row lib-header">
                                <b><?php echo $row["item_name"]; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>

                            <div class="lib-row lib-header">
                            	<p>Manufacturer: <b><?php echo $row2["manufacturer"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Model Name: <b><?php echo $row2["model_name"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Date Of Purchase: <b><?php echo  $q; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Battery Status: <b><?php echo $row2["battery_status"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                                <p> Ad Description: <b><?php echo $row2["ad_descripation"]; ?> <b></p>
                                <hr>
                            </div>

                            <div class="lib-row lib-price">
                            	<p>Bought From </p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Contact Details: <b><?php echo $row3["User_name"]." ".$row3["Mobile_no"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>

                        </div>
                        </div> 	
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
            <!--<?php $_SESSION['ad_id']=$id; ?>-->        
           <!-- <a href="set_buyer.php?id=<?php echo $row["advt_id"]; ?>"><button type="submit" id="sold" name="sold" class="btn btn-primary">SOLD</button></a>-->
                   
          
</div>

<?php
    }
    $help=array();
    $sqll="SELECT DISTINCT product_name FROM electronics where prod_id='$id'";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
      $sql2="SELECT * FROM electronics where prod_id='$id'";
      $result2=mysqli_query($db,$sql2);
      #echo "<script type='text/javascript'>alert('Executing if')</script>" ;
      $row2=mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";

      $sql3="SELECT * FROM users WHERE Nitc_email_id = '$email_id'";
      $result3=mysqli_query($db,$sql3);
      $row3=mysqli_fetch_assoc($result3);

      ?>
        <div class="container">
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                               <b> <?php echo $row["item_name"]; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            
                            <div class="lib-row lib-data">
                              <p>Manufacturer: <b><?php echo $row2["manufacturer"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Model Name: <b><?php echo $row2["model_name"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Date Of Purchase: <b><?php echo $q; ?></b></p>
                            </div>
                            <hr>
                          
                            <div class="lib-row lib-data">
                                <p> Ad Description: <b><?php echo $row2["ad_description"]; ?> <b></p>
                                <hr>
                            </div>
                            <div class="lib-row lib-price">
                              <p>Bought From </p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Contact Details: <b><?php echo $row3["User_name"];?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Mobile No: <b><?php echo $row3["Mobile_no"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                              <p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>
                            <div class="lib-row lib-price">
                              <p>Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
            <!--<?php $_SESSION['ad_id']=$id; ?>-->
            <!--<a href="set_buyer.php?id=<?php echo $row["advt_id"]; ?>"><button type="submit" id="sold" name="sold" class="btn btn-primary">SOLD</button></a>-->

        </div>
</div>
<?php
    }
    $help=array();

    $sqll="SELECT DISTINCT product_name FROM furniture where product_id = '$id'";
    $resultt=mysqli_query($db,$sqll);
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    if($row["item_name"]==$give["product_name"])
    {
      #echo "<script type='text/javascript'>alert('Something is working')</script>" ;
      
      $query2 = "SELECT * FROM furniture WHERE product_id = '$id'";
    	$result2 = mysqli_query($db,$query2);
    	$row2 = mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";

    	$query3 = "SELECT * FROM Users WHERE Nitc_email_id = '$email_id'";
    	$result3 = mysqli_query($db,$query3);
      $row3 = mysqli_fetch_assoc($result3);
      ?>
    <div class="container">
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">

                        <div class="col-md-6">
                        <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                                <b><?php echo $item_name; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            

                            <div class="lib-row lib-header">
                            	<p>Name of Furniture: <b><?php echo $row2["product_name"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Date Of Purchase: <b><?php echo $q; ?></b></p>
                            </div>
                            
                            <div class="lib-row lib-data">
                            	<p>Condition: <b><?php echo $row2["condition_pro"]; ?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                                <p> Ad Description: <b><?php echo $row2["ad_descripation"]; ?> </b></p>
                                <hr>
                            </div>
                            
                            <div class="lib-row lib-header">
                            	<p>Bought From</p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Contact Details: <b><?php echo $row3["User_name"]?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Mobile No: <b><?php echo $row3["Mobile_no"];?></b></p>
                            </div>
                            
                            <div class="lib-row lib-data">
                            	<p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>

                            <div class="lib-row lib-data">
                            	<p>Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
          
                        </div>
                    </div>
                </div>
            </div>
           
            <!--<?php $_SESSION['ad_id']=$id; ?>-->
           <!--<a href="set_buyer.php?id=<?php echo $row["advt_id"]; ?>"><button type="submit" id="sold" name="sold" class="btn btn-primary">SOLD</button></a>-->

<div>
        </div>
</div>  
      
 <?php  
    }
  }
  ?>
 <!--a href="set_buyer.php"><centre><button style="width: 70%;" type="submit" id="sold" name="sold" class="btn btn-primary" >CLICK TO ADD ITEMS</button></centre></a-->	
 
</div>    
</div>
<footer>
  <p align='center'>@ 2021 Copyright <a href="home_2.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>