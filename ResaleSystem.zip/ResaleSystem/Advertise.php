<?php
  require('config/config.php');
?>
<!DOCTYPE html>
<html>
<style type="text/css">
  .logo{

  }

  .container{
    font-size:15px;
    background-color: #B0C4DE;
  }
</style>
<head>
	<title>Adsells</title>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-image: url('pic/bg11.jpg');background-repeat:no-repeat; background-size:100%;">

	<!--<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div class="logo">
      <a class="navbar-brand" href="Home_2.php"><span >Ad</span><span >Sells</span></a>
      </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Change_Password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Top navigation -->
<div class="topnav" stlyle="color:black;">
  <a href="Laptop_Mobile.php">Mobiles & Computers</a>
  <a href="Electronics.php">Electronics</a>
  <a href="Furniture.php">Furnitures</a>
  <div class="topnav-right">
    
  </div>

</div>
</div>

</body>