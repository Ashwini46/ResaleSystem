<?php 
   require('config/config.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Purchase</title>
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

		<link rel="stylesheet" type="text/css" href="css/advertise.css">
		<link rel="stylesheet" type="text/css" href="css/purchase.css">
</head>
<style>
  .container{
    margin-left:15px;
    
  }
</style>
<body style="background-image: url('./wallimg/benefits-bg.svg');background-color:white;
  background-repeat:repeat ; background-size:100%; position:absolute;">
 
	<!--<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="./Laptop_Mobile.php">ADVERTISE</a></li>  
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<br><br>
<!-- Side navigation -->
<div class="sidenav">
<a href="Laptop_Mobile_purchase.php">Mobiles & Computers</a>
  <a href="Electronics_purchase.php">Electronics</a>
  <a href="Furniture_purchase.php">Furniture</a>
  <a href="Purchase.php">All Products</a>

</div>

<?php
{
$help=array();
$query = "SELECT * FROM advertisement_table ";
$result = mysqli_query($db,$query);
$sqll="SELECT DISTINCT product_name FROM electronics";
$resultt=mysqli_query($db,$sqll);
while ($row = mysqli_fetch_assoc($result)) {
    
    $id = $row["ad_id"];
    $email_id = $row["owner_id"];
    $item_name=$row["item_name"];
    $image=["upload_img"];
    #echo $row["item_name"];
    while($roww=mysqli_fetch_assoc($resultt))
  {
    $help[]=$roww;
  }
    foreach($help as $give)
    { 
    //echo $give["product_name"];
    if($row["item_name"]==$give["product_name"])
    {
      #echo "<script type='text/javascript'>alert('Executing if')</script>" ;
      $sql2="SELECT * FROM electronics where prod_id='$id'";
      $result2=mysqli_query($db,$sql2);
      #echo "<script type='text/javascript'>alert('Executing if')</script>" ;
      $row2=mysqli_fetch_assoc($result2);
      $item_name=$row["item_name"];
      $uplodedir="upload/";

      $sql3="SELECT * FROM users WHERE Nitc_email_id = '$email_id'";
      $result3=mysqli_query($db,$sql3);
      $row3=mysqli_fetch_assoc($result3);

    	?>
        <div class="container">
            <div class="row row-margin-bottom">
            <div class="col-md-9 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img-show" src=<?php echo "upload/".$row["upload_img"]; ?>>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                               <b> <?php echo $row["item_name"]; ?></b>
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-header">
                            	<p>Manufacturer: <b><?php echo $row2["manufacturer"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Model Name: <b><?php echo $row2["model_name"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Year Of Purchase: <b><?php echo $row2["year_of_purchase"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                                <p> Ad Description: <b><?php echo $row2["ad_description"]; ?></b> </p>
                                <hr>
                            </div>
                            <div class="lib-row lib-price">
                            	<p>Expected Price: Rs <b><?php echo $row2["expected_price"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Name: <b><?php echo $row3["User_name"];?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Contact Details: <b><?php echo $row3["Mobile_no"]; ?></b></p>
                            </div>
                            <div class="lib-row lib-data">
                            	<p>Email ID: <b><?php echo $row["owner_id"];?></b></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-1"></div>
            
        </div>
</div>
<?php
    }
    }
  }
}
?>
<br><br>
<a href="set_buyer.php"><centre><button style="width: 70%; margin-left:100px;" type="submit" id="sold" name="sold" class="btn btn-primary" >CLICK TO SELL ITEMS</button></centre></a>	
<br><br><br>


<p align='center'>@ 2021 Copyright: <a href="home_2.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>
