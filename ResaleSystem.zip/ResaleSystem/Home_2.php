<?php
 require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Adsells</title>
	<link rel="stylesheet" type="text/css" href="css/home.css">
	<link rel="stylesheet" type="text/css" href="css/footer.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
.tp1{
	color: white;
	font-size: 80px;
	margin-top: 200px;
}
header {
    background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('./wallimg/wal1.jpg');
    height: 95vh;
    background-size: cover;
    background-position: center;
}
.main-nav li.active a {
    border: 1px groove black;
    background-color: white;
    color:black;
	border-radius: 10px;
}
.main-nav li a:hover {
    border: 1px groove black;
    background-color: white;
    color:black;
	border-radius: 10px;

}
.btn-one:hover,.btn-two:hover {
    background-color: white;
	color:black;
	font-size:18px;
    transition: all 0.5s ease-in;
}
</style>
<body>
    <header>
	<div class="container" style="background-color:transparent;margin-left:40px">
		<div class="row">
		<h3 style="float: left; padding-left: 35px; color: white; font-size: 40px;font-weight: bold;text-align: center;"><span >Ad</span><span>Sells</span></h3>
		</div>
		<div style="margin-left:-25px;margin-right:950px;margin-top:-70px;text-align:center">
			<h5 style="margin-top:65px;color:white;">Your next-door convenient store !</h5>	
			</div>		
	</div>
    <div class="row" style="margin-left:435px;margin-top:-70px">
      	<ul class="main-nav" style="margin-top:10px;font-size:16px;">
    		<li class="active"><a href="home_2.php">HOME</a></li>
    		<li><a href="My_Products.php">MY PRODUCTS</a></li>
        <li><a href="Bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="Message.php">MESSAGES</a></li>
    		<li><a href="about_us.php">ABOUT US</a></li>
    		<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="home.php" ><span class="caret"></span></a>
    		<ul class="dropdown-menu">
    			<li><a href="Change_Password.php">Change Password</a></li>
    			<li><a href="logout.php">Logout</a></li>
    		</ul>
    		</li>
    	</ul>
    </div>
	
   
<center>
    <div class="text-center">
        <h1 class="tp1">Are You Ready?</h1>
        <div class="button" style="margin-left:-10px">
        	<a href="./Laptop_Mobile.php" class="btn-one button_n" style="font-size:18px;">Advertise</a>
        	<a href="purchase.php" class="btn-two button_n" style="font-size:18px;">Purchase</a>
        </div>
    </div>
    </center>
    </header>

<footer class="container-fluid bg-4 text-center" style="color:white">
  <p>@ 2021 Copyright <a href="home_2.php" style="color:white">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>  
</body>
</html>


