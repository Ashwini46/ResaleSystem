<?php
 require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
  
</style>
	<title>Adsells</title>
	<!-- <link rel="stylesheet" type="text/css" href="css/home.css"> -->
	<link rel="stylesheet" type="text/css" href="css/footer.css">
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body style="background-image: url('pic/Home.jpg');
  background-repeat:no-repeat; width:1400px;background-size:100%;position:fixed;">
 <?php
         header("refresh:8; url=http://localhost/ResaleSystem/login.php");
    ?>
  <!--h1 style="Color:white;font-size:70px;margin-top:100px">AdSells</h1-->
    <div class="circular" style="margin-top:100px;">
      <div class="inner">
</div>
<div class="outer">
</div>
<div class="numb">
0%</div>
<div class="circle">
        <div class="dot">
          <span></span>
        </div>
<div class="bar left">
          <div class="progress">
</div>
</div>
<div class="bar right">
          <div class="progress">
</div>
</div>
</div>
</div>
<script>
      const numb = document.querySelector(".numb");
      let counter = 0;
      setInterval(()=>{
        if(counter == 100){
          clearInterval();
        }else{
          counter+=1;
          numb.textContent = counter + "%";  
        }
      }, 75);
    </script>


<!--<footer class="container-fluid bg-1 text-center "> -->    
</body>
</html>