<?php
session_start();/* Session */
$db=mysqli_connect("localhost","root","","myproject"); /*Database Connection*/
?>
