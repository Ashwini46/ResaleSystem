<?php
  require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/valid.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  footer{
    margin-top:10px;
    position: absolute;
    bottom: 0;
    width: 100%;
    background-color:white;
    
  }
  .form-control{
    border:1px solid black;
   
  }
    input {
    width: 100%;
    padding: 12px;
    border: 1px solid black;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 5px;
    margin-bottom: 16px;
    
}


/* Style the submit button */

input[type=submit] {
    background-color: #4CAF50;
    color: white;
}


/* Style the container for inputs */

.container {
   
    padding: 20px;
}
.field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}

/* The message box is shown when the user clicks on the password field */

#message {
    display: none;
    background: white;
    color: #000;
    position: relative;
    padding: 20px;
    margin-top: -30px;
    width: 40%;
    margin-left: 300px;
    height: 250px;
}

#message p {
    padding: 5px 20px;
    font-size: 16px;

}


/* Add a green text color and a checkmark when the requirements are right */

.valid {
    color: green;
}

.valid:before {
    position: relative;
    left: -35px;
    content: "✔";
}


/* Add a red text color and an "x" when the requirements are wrong */

.invalid {
    color: red;
}

.invalid:before {
    position: relative;
    left: -35px;
    content: "✖";
}
</style>
<body style="background-image: url('./wallimg/benefits-bg.svg');
  background-repeat:no-repeat; background-size:100%;" onLoad="noBack();" >

<!--	<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="./Laptop_Mobile.php">ADVETISE</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="change_password.php" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <h2 style="text-align:center">Change Password</h2>
  <form class="form-horizontal" action="change_password.php" method="post">
    <br>
    <div class="form-group">
      <label class="control-label col-sm-2" for="curr_pass">Current Password</label>
      <div class="col-sm-10">
        <input type="password" class="form-control" id="curr_pass" placeholder="Current Password" name="curr_pass" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="new_pass">New Password</label>
      <div class="col-sm-10">
        <input type="password" class="form-control" id="new_pass" placeholder="New Password" name="new_pass" required>
        <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
      </div>
    </div>
  <div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A lowercase letter</p>
  <p id="capital" class="invalid">A capital (uppercase) letter</p>
  <p id="number" class="invalid">A number</p>
  <p id="length" class="invalid">Minimum 8 characters</p>
</div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="retype_new_pass">Current Password</label>
      <div class="col-sm-10">
        <input type="password" class="form-control" id="retype_new_pass" placeholder="Retype New Password" name="retype_new_pass" required>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" name="submit" id="submit" class="btn btn-primary">Change</button>
      </div>
    </div>
  </form>
</div>

  <p align='center' style="margin-top:160px">@ 2021 Copyright <a href="home.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>

<?php
   $email_id = $_SESSION['email'];
   if(isset($_POST['submit'])){
   $query1 = "SELECT * FROM Users WHERE Nitc_email_id = '$email_id'";
   $result1 = mysqli_query($db,$query1);
   $row1 = mysqli_fetch_assoc($result1); 
   $curr_password = mysqli_escape_string($db,$_POST['curr_pass']); //current password taken as input
   $current_pass = $row1["User_password"]; // current password of the user
   if($current_pass == $curr_password){
       $new_password = mysqli_escape_string($db,$_POST['new_pass']);
       $retype_new_password = mysqli_escape_string($db,$_POST['retype_new_pass']);
       if($new_password == $retype_new_password){
             $query2 = "UPDATE Users SET User_password = '$new_password' WHERE Nitc_email_id = '$email_id'";
             //$query2 = "UPDATE Users SET Confirm_password = '$new_password' WHERE Nitc_email_id = '$email_id'";
             $result2 = mysqli_query($db,$query2);
             if($result2){
               echo "<script type='text/javascript'>alert('Password succesfully changed')</script>";
             }
       }else{
          echo "<script type='text/javascript'>alert('New Password and Retype Password are not same!')</script>";
          exit; 
       }
   }
   else{
       echo "<script type='text/javascript'>alert('Current Password you entered is Incorrect!')</script>";
   }

}
?>
<script>
var myInput = document.getElementById("new_pass");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
</body>