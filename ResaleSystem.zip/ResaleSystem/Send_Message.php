<?php
  require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Website Title</title>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  .color-white{
    color: white;
  }
  .chat{
    margin-left:220px;
    Font-size:25px;
  }
  .conn{
    font-size:15px;
    
  }
</style>
<style type="text/css">
  footer{
    position: absolute;
    bottom: 0;
    width: 100%;
  }
</style>
<body style= "background-repeat:repeat-y; background-size:100%; position:absolute;background-image: url('./wallimg/benefits-bg.svg')">


  <div class="container conn">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
          <li><a href="./Laptop_Mobile.php">ADVETISE</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>


<div class="container">
  <h2 align="center" style="margin-top:50px">Send Messages</h2><br><br>
  <div class="container">
  <div class="row">
  <?php
    $email_id = $_SESSION['email'];
    $query = "SELECT * FROM Messages WHERE receiver_id ='$email_id'";
    $result = mysqli_query($db,$query);
    $send="SELECT count(sender_id) FROM Messages";
    while ($row = mysqli_fetch_assoc($result)){
          $sender_id = $row["sender_id"];
          $query3="select message from messages where sender_id='$sender_id'";
          $result3=mysqli_query($db,$query3);
          $row3=mysqli_fetch_assoc($result3);
          $query2 = "SELECT *FROM Users WHERE Nitc_email_id = '$sender_id'";
          $result2 = mysqli_query($db,$query2);
          $row2 = mysqli_fetch_assoc($result2);
          $sender_name = $row2["User_name"]; 
          ?> 
         <div class="container">
        <div class="row row-margin-bottom">
            <div class="col-md-12 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                            <div class="lib-row lib-data chat">
                                
                            </div>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
            <!--<div class="col-md-1"></div>-->
        </div>
      </div>    
    <?php
    } 

?>
  </div>
  </div>
  <form class="form-horizontal" action="send_message.php" method="post">
    <div class="form-group">
      <label class="control-label col-sm-2" for="advt_id">Email ID :</label>
        <div class="col-sm-10" id="result">
        <?php
        if(isset($_GET['email']))
        { 
        $email=$_GET['email'];
        if($email)
        {
          ?>

          <input type="email" class="form-control" id="email_id" placeholder="Email ID of Receiver"  value="<?php echo $_GET['email'] ?>" name="email" disabled="disabled" required>
        <?php 
        }
      }
      else
      {
        ?>
    
        <input type="email" class="form-control" id="email_id" placeholder="Email ID of Receiver"   name="email" required>
       <?php
       }
        ?> 
        
        </div>
      </div>
  
    
       

    <div class="form-group">
      <label class="control-label col-sm-2 " for="msg">Message description</label>
      <div class="col-sm-10">          
        <textarea class="form-control" id="msg" placeholder="Message description" name="msg"></textarea>  
      </div>
    </div>
    

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-9">
        <button type="submit" id="submit" name="submit" class="btn btn-primary">SEND</button>
      </div>
    </div>
</form>
</div>
<br><br><br><br>
<footer>
  <p align='center' style="margin-bottom:-400px;">@ 2021 Copyright <a href="home_2.php">www.adsells.com </a>| Designed by Ashwini | Arpitha Angya</p> 
</footer>

<?php
  
  $email_id = $_SESSION['email'];

  if(isset($_POST['submit'])){
    $rec_email = mysqli_escape_string($db,$_POST['email']);

    $message = mysqli_escape_string($db,$_POST['msg'] );
   
    $today_date =  date("Y-m-d");
    date_default_timezone_set('Asia/Kolkata');
    $time = date("h:i:s");
    
    $query = "INSERT INTO Messages (sender_id,receiver_id,message,msg_date,msg_time) VALUES ('$email_id','$rec_email','$message','$today_date','$time')";
    $result = mysqli_query($db,$query);
    if($result){
         echo "<script type='text/javascript'>alert('Message sent Successfully!')</script>";
    }
    else{
         echo "<script type='text/javascript'>alert('Error in sending message!!! Please try again.')</script>";
    }
  }
?>
