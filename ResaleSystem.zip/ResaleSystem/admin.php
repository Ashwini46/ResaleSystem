<?php 
   require('config/config.php'); 
?>
<!doctype html>


<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Admin</title>
    <style>
    .con{
        margin-top:-530px;
        align:center;
        max-width:470px;
        background-color:white;
    }
    .myDIV{
         display: none; }
    }
    .table{
      border: 2px solid black;
    }
    .tablee{
      color:black;
      width:100%;
      font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
      font-size:14px;
    }
    .coln{
      height:520px;
      width:400px;
      background-color:white;
    }
    </style>
<script>
function showDiv() {
    div = document.getElementById('tow');
    div.style.display = "block";
}
</script>
<head>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-image: url('./wallimg/adwal1.jpg');background-repeat:no-repeat; background-size:100%;">
	<!--<nav class="navbar navbar-inverse"> -->
     <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top:-400px;height:50%;width:100%; object-fit: contain;font-family: 'Times New Roman', Times, serif;">
          <div class="content" style="align-item:center;text-align: center; margin-top:450px">
            <h2 style="color:white;text-align: center;font-family:'Helvetica';font-size:60px;">
              Adsells Admin
            </h2>
        </div>
    </div>
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar" style="margin-top:-300px">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"><a href="admin.php" class="dropdown-toggle" data-toggle="dropdown" style="color:white;"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="home_2.php">Home</a></li>
          <li><a href="adminlogin.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
  </nav>
  <div class="container">
  <?php 
  if(isset($_POST['delete']))
  {
    $key=$_POST['check'];
    //checking
    $check=mysqli_query($db,'SELECT * FROM admin');
    if(mysqli_num_rows($check)>0)
    {
        $querydelete=mysqli_query($db,"DELETE FROM admin where id=$key");
        echo "<script type='text/javascript'>alert('Selected item is deleted')</script>";

    }
    else{
      echo "<script type='text/javascript'>alert('Record Not Found')</script>";
    }

  }
  ?>
    <div class="navbar-header">

      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <!--div class="logo">
      <a class="navbar-brand" href="admin.php"><span><h1 style="margin-top:-50px;color:white;font-size:40px">Admin</h1></span></a>
      </div-->
    </div>
</div>

<div class="container coln "style="margin-left:700px; width:500px;margin-top:10px">
<div class="row">
<h2 class="color-black" style="margin-top:10px;">Delete Items</h2><br>
<form class="form-horizontal" action="Admin.php" method="post" >
<div class="form-group">
        <label class="control-label col-3" for="protype">Product Type</label>
        <div class="col-1">
        
        <select class="form-control" id="protypee" name="protypee"  required style="width:350px;margin-left:30px;">
        <?php 
        echo"<option>---------------------------SELECT--------------------------------------</option>";
        $sqli="SELECT DISTINCT(item_type) from admin";
        $ress=mysqli_query($db,$sqli);
        while($roww=mysqli_fetch_assoc($ress)){  
        echo "<option value='".$roww['item_type']."'>" .$roww['item_type']." </option>";     
      }?>
    </select>
    </div>
    <button type="submit" id="button1" name="button1" class="btn btn-primary" style="margin-left:400px;margin-top:-55px;">--</button>
    <script>
   function myFunction(myDIV) {
    document.getElementById(myDIV).style.display = 'block';
}
</script> 
    </div>
        <div class="form-group" class="answer_list" id="myDiv">
        <label class="control-label col-3" for="protype" >Product Name</label>
        <div style="width:400px;height:230px;overflow-y:scroll;margin-left:50px;margin-top:10px;">
        <?php 
        {
          if(empty($_POST["protypee"]))
          {
            echo"<h3>NO ITEM SELECTED YET !</h3>";
          }
          else if(!empty($_POST['protypee']))
          { 
        $help=$_POST['protypee'];
        $sqli="SELECT * from admin where item_type='$help' GROUP by item_name order by item_name asc";
        //SELECT DISTINCT item_name FROM admin GROUP BY(id)
        $ress=mysqli_query($db,$sqli);
        ?>
        <table class="tablee" style="padding:500px;">
        <tr>
        <th style="margin-left:10px;">Item</th>
        </tr>
        <?php
          }
          while($roww=mysqli_fetch_assoc($ress))
        {  
        ?>
        <tr>
        <td style="border-bottom:1px solid lightgray;padding:15px;"><input type="checkbox" id=<?php $roww['id']; ?>class="help" name="check" value="<?php echo $roww['id']; ?>">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo $roww['item_name']; ?></b>
        </td>
        </tr>
        <?php
        //echo $roww['id'];
          }
        }
      
        ?>  
        </table>
    </div>
    </div>
      <div class="form-group">        
      <div class="col-3">
        <a href="admin.php"><button type="submit" id="delete" name="delete" class="btn btn-danger" style="margin-left:50px;margin-top:50px;" onclick="myFunction()">Delete</button></a>
      </div>
    </div>
    <!--./id-->

</div>
<!--./row-->
</div>
<!--./conatiner-->
</form>
<!---------------------------------------------Insertion form-------------------------------------------------------------------------------------->
<form class="form-horizontal" action="Admin.php" method="post">
<div class="container con" style="margin-left:50px;margin-top:-520px">

  <h2 class="color-black">Update Items</h2><br>
  <form class="form-horizontal" action="Admin.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
        <label class="control-label col-3" for="protype">Product Type</label>
        <div class="col-5">

        <select class="form-control" id="protypee" name="protype"  required style="width:400px;margin-left:30px;">
        <?php 
        echo"<option>---------------------------SELECT--------------------------------------</option required>";
      $sqli="SELECT DISTINCT(item_type) from admin ";
      #SELECT * FROM `admin` ORDER BY `admin`.`item_type` ASC
      $ress=mysqli_query($db,$sqli);
      while($roww=mysqli_fetch_assoc($ress)){  
      echo "<option value='".$roww['item_type']."'>" .$roww['item_type']."</option>";    
    }?>
    </select>  

    </div>
    </div>

    <div class="form-group">
      <b><label class="control-label col-3 color-black" for="proname">Product Name</label></b>
      <div class="col-6">          
        <input type="text" class="form-control" id="proname" placeholder="Product Name" name="proname" required style="width:400px;margin-left:30px;">
      </div>
    </div>

    <div class="form-group">        
      <div class="col-3">
        <a href="admin.php"><button type="submit" id="submit" name="submit" class="btn btn-primary" style="margin-left:30px;">Update</button></a>
      </div>
    </div>

    <div class="form-group" style="width:400px;height:218px">        
      <div  style="width:470px;height:230px;overflow-y: scroll;">
      <table class="Table" id="protypee" name="protypee"  required style="width:400px;margin-left:50px;size=4;padding:150px;position:fixed">
      <?php
        $sql="SELECT DISTINCT item_type,item_name from admin ORDER by item_type ASC";
        $res=mysqli_query($db,$sql);
        $mia=mysqli_query($db,'SELECT * FROM `admin` ORDER by item_type');
        
        //$po=$_POST['protype'];
        //echo $po;
        ?>
        <table class="table" style="padding:20px;">
        <tr>
        <th style="margin-left:50px;">Item</th>
        <th>Item type</th>
        </tr>
        <?php
        while($row=mysqli_fetch_assoc($res)){
          ?>
          <tr> 
          <td><?php echo $row['item_name']?></td>
          <td><?php echo $row['item_type']?></td>
          </tr>

          <?php  
          } 
        ?>
      </div>
    </div>
</div>
    </form>
<?php
$db = mysqli_connect("localhost", "root","", "myproject");
//$ash=$_POST['submit'];
if(isset($_POST['submit']))
{
//echo "<script type='text/javascript'>alert('Trying to access db!')</script>";
$itemname=$_POST['proname'];
$itemtype=$_POST['protype'];
$selelt=mysqli_query($db,"Select * from admin where item_type='$itemtype'");
$help=mysqli_query($db,"SELECT count(item_name) from admin where item_name='$itemname' ");
$why=mysqli_fetch_assoc($help);
$i=(int)$why;
while($r=mysqli_fetch_assoc($selelt))
{
  $i=(int)$r['item_name'];
  if($i!=0)
  {
    //echo $r['item_name'];
    echo "<script type='text/javascript'>alert('Item Already exist')</script>";
    exit;
   // header('location:Admin.php');
  }
  else{
  $query = "INSERT INTO admin (item_type,item_name) VALUES ('$itemtype','$itemname')";
  $result = mysqli_query($db,$query);
    if($result)
    {
     echo "<script type='text/javascript'>alert('Update in table !')</script>";
     exit;
     #window.location.reload(true);
}
else
{
     echo "<script type='text/javascript'>alert('Error in Adding Item!!! Please try again.')</script>";
     exit;
}
  }
}
}
?>
</body>
</html>
