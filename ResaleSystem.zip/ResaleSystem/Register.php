
<head>
 <meta charset="utf-8">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="css/Global.css">

 <style>
 input {
  width: 100%;
  padding: 12px;
  border: 1px solid black;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
}

/* Style the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
}

/* Style the container for inputs */
.container {
  background-color: #f1f1f1;
  padding: 20px;
}

/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: transperent;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: -500px;
  width:30%;
  margin-left:900px;
  hight:100px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid{
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}

 </style>
</head>
<body style="background-image: url('pic/bg5.jpg');
  background-repeat:no-repeat; background-size:100%;" onLoad="noBack();" >
<div class="container-fluid bg">
	<div class="row">
		<div class="col-md-4 col-sm-4 col-xs-12"></div>
		<div class="col-md-4 col-sm-4 col-xs-12">
			<!--form start-->
<form action="Register.php" method="post" class="form-container">
  <h1>Registration Form</h1>
  <div class="form-group">
    <label for="name">Full Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
  </div>
  <div class="form-group">
    <label for="mob_no">Mobile Number</label>
    <input type="number" class="form-control" id="mob_no" name="mob_no" placeholder="Mobile Number" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Confirm Password</label>
    <input type="password" class="form-control" id="con_password" name="con_password" placeholder="Confirm Password" required>
  </div>
  
  <input type="submit" value="Submit" name="submit" id="submit" class="btn btn-success btn-block">
  <br>
  <p>Click here to <a href="login.php">Login</a></p>
</form>

            <!--form ends-->
		</div>
        <div class="col-md-4 col-sm-4 col-xs-12"></div>
	</div>
</div>
<div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A lowercase letter</p>
  <p id="capital" class="invalid">A capital (uppercase) letter</p>
  <p id="number" class="invalid">A number</p>
  <p id="length" class="invalid">Minimum 8 characters</p>
</div>
<?php
//$db = mysqli_connect('localhost','root','','myproject');
$servername = "localhost";
$dbuser = "root";
$dbpassword = "";
$dbname="myproject";
//connection 
$conn =mysqli_connect($servername,$dbuser,$dbpassword,$dbname);
if(isset($_POST['submit']))
{
  $user_name = $_POST['name'] ;
  $mobile_no = $_POST['mob_no'];
  $confirm_password = $_POST['con_password'];
  $email_address = $_POST['email'];
  $password =$_POST['password'];
  if($password != $confirm_password)
  {
    echo "<script type='text/javascript'>alert('New Password and Retype Password are not same!')</script>";
          exit; 
  }
  
  if($conn->connect_error)
  {
    die('connect error:'.$conn->connect_error);
    echo "<script type='text/javascript'>alert('Registration Failed. Please try again')</script>";
  }
  else
  {
    $stm=$conn->prepare("insert into users (Nitc_email_id,User_name,Mobile_no,User_password) VALUES (?,?,?,?)");
    $stm->bind_param("ssis",$email_address,$user_name,$mobile_no,$password );
    echo "<script type='text/javascript'>alert('Submitted succesfully!!!')</script>";
    $stm->execute();
    
    header("Location:http://localhost/myProject/login.php");
    exit();
  }
  $stm->close();
  $con->close();
}
?>
<script>
var myInput = document.getElementById("password");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
</body>