<?php  
require 'config/config.php';
?>


<head>
 <meta charset="utf-8">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="css/Global.css">
</head>
<style>
  .form-container {
    border: 0px solid white;
    padding: 30px 40px;
    font-family: 'Times New Roman', Times, serif;
    text-decoration-color: black;
    margin-top: 10%;
    background-color: white;
    -webkit-box-shadow: 1px 4px 26px 11px rgba(25, 190, 255, 0.192);
    -moz-box-shadow: 1px 4px 26px 11px rgba(0, 0, 0, 0.75);
    box-shadow: 1px 4px 26px 11px rgba(25, 190, 255, 0.192);
  }
  .c1{
      font-size: 14px;
      font-family:Arial;
  }
  
  
</style>
<body style="background-image: url('./wallimg/fullscreenblue.svg');
  background-repeat:no-repeat; background-size:100%;">

  <!--<header class="login_h">
  <h2>Rent IT On<h2>
</header>-->

<div class="container-fluid bg">
	<div class="row">
		<div class="col-md-6 col-sm-6 col-xs-12" style="background-image: url('./wallimg/ad1.jpg');background-repeat: no-repeat;height: 100%;width:50%; object-fit: contain;font-family: 'Times New Roman', Times, serif;">
      <div class="content" style="align-item:center;text-align: center; margin-top:400px">
        <h3 style="color:white;line-height: 1.6;font-family:'Lucida Handwriting'">
         "The key is when a customer walks away, thinking, 'Wow, I love doing business with them, and I want to tell others about the experience."
        </h3>
        <h2 style="color:white;text-align: center;font-family:'Georgia'">
          -Welcome to Adsells
        </h2>
      </div>
    </div>
		<div class="col-md-4 col-sm-4 col-xs-12" style="margin-left:100px;margin-right:50px" >
			<!--form start-->
      <br>
      <br><br>
    <form action='login.php' method="post" class="form-container">
    <br><br>
    <img src="pic/avatar.png" class="avatar" style="margin-left:25%;">
      <h1>Login Form</h1>
      <div class="form-group c2">
        <label  for="exampleInputEmail1">Email address</label>
        <input type="email" class="form-control c1" id="email" name="email" placeholder="Email" required>
      </div>
      <div class="form-group c2">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control c1" id="password" name="password" placeholder="Password" required>
      </div>
    
      <br>
      <input type="submit" id="submit" name="submit" value="Submit" class="btn btn-success btn-block" style="border:10px;">
      <br>
      <p>If not Registered?<a href="Register.php"style="text-decoration: none;">&nbsp&nbsp&nbsp Click Here</a></p>
      <p>Login as Admin<a href="adminlogin.php"style="text-decoration: none;" >&nbsp&nbsp&nbsp&nbsp Admin </a></p>
    </form>

            <!--form ends-->
		</div>
        <div class="col-md-4 col-sm-4 col-xs-12"></div>
    </div>
  </div>
</div>

<?php
    $servername = "localhost";
    $dbuser = "root";
    $dbpassword = "";
    $dbname="myproject";
    //connection 
    $db =mysqli_connect($servername,$dbuser,$dbpassword,$dbname);
   if(isset($_POST['submit'])){
     $email_address = ($_POST['email']);
     $password = trim($_POST['password']);
     
     $email_address=stripcslashes($email_address);
     $password=stripcslashes($password);
     $email_address=mysqli_real_escape_string($db,$email_address);
     $password = mysqli_real_escape_string($db, $password); 

     $query = "SELECT *FROM Users WHERE Nitc_email_id = '$email_address' AND User_password='$password'";
     $result = mysqli_query($db,$query);

     if(mysqli_num_rows($result)==1){
           $_SESSION['email'] = $email_address;
           $_SESSION['password']=$password;
           $_SESSION['success'] = "You are now logged in";
           header('location: Home_2.php');
     }
     else{
           echo "<script type='text/javascript'>alert('Failed to Login! Incorrect Email or Password')</script>";
     }
   }
?>
