<?php
  require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Website Title</title>
	<link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  .color-white{
    color: white;
  }
  .form-control{
    border:1px solid black;
    width:400px;
  }
</style>
<body style="background-color:white;background-size:100%;">

	<!-- <nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>
 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home_2.php">HOME</a></li>
        <li><a href="my_products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        <li><a href="message.php">MESSAGES</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Top navigation -->
<div class="topnav" style="background-color:#0099ff;margin-left:1px">

  <!-- Left-aligned links (default) -->
  <a href="Laptop_Mobile.php">Mobiles & Computers</a>
  <a href="Electronics.php">Electronics</a>
  <a href="Furniture.php">Furnitures</a>
  <div class="topnav-right">
  </div>
</div>
<div class="col-md-6 col-sm-6 col-xs-12" style="background-image: url('./wallimg/el1.png');background-repeat: no-repeat;max-height: 100%;max-width:100%;display: block; object-fit: fill;background-color:white;font-family: 'Times New Roman', Times, serif;">
      <div class="content" style="align-item:center;text-align: center; margin-top:500px">
        <h3 style="color:black;line-height: 1.6;font-family:'Lucida Handwriting'">
        "I had to make my own living and my own opportunity. But I made it! Don’t sit down and wait for the opportunities to come. Get up and make them."
        </h3>
      </div>
    </div>
	<div class="container" style="background-color:white;margin-left:608px;margin-right:200px;height:630px;width:740px;">
  <h2 class="color-black" style="text-align:center">Post an Advertisement</h2><br>
  <form class="form-horizontal" action="Electronics.php" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2 color-black" for="product_name">Product Name</label>
      <div class="col-sm-8">
      <select  class="form-control" id="product_name" name="product_name" required>
      <option selected>----------------------------------------Select----------------------------------------</option>
      <?php 
      $sql="SELECT DISTINCT(item_name) from admin where item_type='Elecronics'";
      $res=mysqli_query($db,$sql);
      while($row=mysqli_fetch_assoc($res)){
        
      echo "<option value='".$row['item_name']."'>" .$row['item_name']."</option>";    
    }?>
      </select>
      </div>
    </div>

    <div class="form-group" style="margin-top:-540px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="manufacturer">Manufacturer</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="manufacturer" placeholder="Manufacturer" name="manufacturer" required>
      </div>
    </div>

    <div class="form-group"style="margin-top:-490px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="model_name">Model Name</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="model_name" placeholder="Model Name" name="model_name" required>
      </div>
    </div>

    <div class="form-group" style="margin-top:-440px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="yop">Year of Purchase</label>
      <div class="col-sm-6">          
        <input type="number" class="form-control" id="yop" placeholder="Year of Purchase" name="yop" min='1900' max='2021' required>
      </div>
    </div>

    <div class="form-group" style="margin-top:-390px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="description">Ad description</label>
      <div class="col-sm-6">          
        <textarea class="form-control" id="description" placeholder="Ad description" name="description" ></textarea>  
      </div>
    </div>

    <div class="form-group" style="margin-top:-320px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="expected_price">Expected Price</label>
      <div class="col-sm-6">          
        <input type="number" class="form-control" id="expected_price" placeholder="Expected Price" name="expected_price" min=100 required>
      </div>
      </div>
      
      <div class="form-group" style="margin-top:-270px;margin-left:64px">
      <label class="control-label col-sm-2 color-black" for="uploadfile">Upload Image</label>
      <div class="col-sm-6">          
      <input type="file" id="uploadfile" value=" " class="form-control" name="fileUpload[]" multiple="multiple" required>
      </div>
    </div>

    <div class="form-group"  style="margin-top:-200px;margin-left:200px">        
      <div class="col-sm-offset-2 col-sm-6">
        <button type="submit" style="width:200px"name="submit" id="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </form>
</div>
</body>

<?php
    $db = mysqli_connect("localhost", "root","", "myproject"); 
    $today =  Date("Y-m-d");
    $expiry = Date("Y-m-d",strtotime("+10 days"));
    //echo $today." ".$expiry;
    $owner_email = $_SESSION['email'];
    //echo $owner_email;

    if(isset($_POST['submit']))
    {
      #echo "<script type='text/javascript'>alert('Trying to insert value')</script>";
      $productName = $_POST['product_name'];
      $manufacturer =$_POST['manufacturer'];
      $modelName = $_POST['model_name'];
      $yearOfPurchase =$_POST['yop'];
      $description = $_POST['description'];
      $expectedPrice =$_POST['expected_price'];
      $Electronics="Elecronics";
      
      
    
    #echo "<script type='text/javascript'>alert('Trying to uploade image')</script>";
    $uploadsDir = "upload/";
    $allowedFileType = array('jpg','png','jpeg');

    if (!empty(array_filter($_FILES['fileUpload']['name']))) {
          foreach($_FILES['fileUpload']['name'] as $ad_id=>$val)
          {
            $fileName        = $_FILES['fileUpload']['name'][$ad_id];
            $tempLocation    = $_FILES['fileUpload']['tmp_name'][$ad_id];
            $targetFilePath  = $uploadsDir . $fileName;
            $fileType        = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            if(in_array($fileType,$allowedFileType))
            {
              if(move_uploaded_file($tempLocation,$targetFilePath))
              {
                $sqlval="('".$fileName."')";
              }else{
                $respose=array("status"=>"alter-danger","message"=>"File Could not be uploade");
              }
            }else{
              $respose=array("status"=>"alter-danger","message"=>"File Format not allowed");
            }
      
      #insert into advertisment
      if(!empty($sqlval))
    {
      $sql1="INSERT INTO advertisement_table (item_name,item_type,date_of_init,date_of_exp,owner_id,upload_img) VALUES ('$productName','$Electronics','$today','$expiry','$owner_email','$fileName')";
      $result1=mysqli_query($db,$sql1); 
      #echo "<script type='text/javascript'>alert('Trying to accesss advirtisment table')</script>";
      
      
      if($result1)
    {
      $sql3="SELECT ad_id from advertisement_table  where item_name='$productName' and owner_id='$owner_email'";
      $result2=mysqli_query($db,$sql3);
      $row=mysqli_fetch_assoc($result2);
      $temp=$row["ad_id"];

      #$row=mysqli_fetch_assoc($result2);
      #$temp=$row["prod_id"];
      #echo "<script type='text/javascript'>alert('Advertisement table Successfully')</script>";

      #insert into electronics
      $sql2="INSERT INTO electronics (prod_id,product_name,manufacturer,model_name,year_of_purchase,ad_description,expected_price,upload_img) VALUES ('$temp','$productName','$manufacturer','$modelName','$yearOfPurchase','$description','$expectedPrice','$fileName')";
      $result3=mysqli_query($db,$sql2); 
  
      echo "<script type='text/javascript'>alert('Advertisement Posted Successfully')</script>";
    }
    }
  }
}

}

?>