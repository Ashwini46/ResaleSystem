<?php
  require('config/config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Website Title</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
  <link rel="stylesheet" type="text/css" href="css/advertise.css">
  <link rel="stylesheet" type="text/css" href="css/purchase.css">
</head>
<style type="text/css">
  .color-white{
    color: white;
  }
  .card{
    margin: 1px;
    border: 1px;
  }
  .container{
    
  }
  .box-shadow{
    height:150px;
    overflow-y: scroll;
  }
</style>
<body style="background-image: url('./wallimg/benefits-bg.svg');background-color:white;
  background-repeat:repeat ; background-size:100%; position:absolute;" >

<!--	<nav class="navbar navbar-inverse"> -->
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <a class="navbar-brand" href="home_2.php" style="font-size:50px;color:Black;font-family:Papyrus">Adsells</a>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="Home_2.php">HOME</a></li>
        <li><a href="Purchase.php">ALL PRODUCT</a></li>
        <li><a href="My_Products.php">MY PRODUCTS</a></li>
        <li><a href="bought_products.php">BOUGHT PRODUCTS</a></li>
        
        <li><a href="./Laptop_Mobile.php">ADVERTISE</a></li>
        <li><a href="about_us.php">ABOUT US</a></li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['email']; ?><span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="change_password.php">Change Password</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div>
  <div>
    <h1 style="text-align:center;margin-top:30px;text-decoration: underline;font-family:Georgia">Messages</h1>
  </div>
</div>
<?php
if(isset($_['sold']))
{
  $email=$_POST['emailid'];
}
    $email_id = $_SESSION['email'];
    $query = "SELECT * FROM Messages WHERE receiver_id ='$email_id' group by(sender_id)";
    $samp="SELECT * FROM Messages WHERE receiver_id ='$email_id'";
    $is=0;
    $result = mysqli_query($db,$query);
    $ans=mysqli_query($db,$samp);
    
    /*if($result=mysqli_query($db,$query))
    {
      $row1=mysqli_fetch_assoc($result);
      $want=$row1['sender_id'];
      echo $want;
    }*/
   /* <?php
        while($r=mysqli_fetch_assoc($ans))
                                    {
                                      $ms=$r['message'];
                                     echo $ms;
                                   }
                            ?> */
    while ($row = mysqli_fetch_assoc($result))
    {
          $sender_id = $row["sender_id"];
          $query2 = "SELECT *FROM Users WHERE Nitc_email_id = '$sender_id'";
          $int="SELECT count(*)FROM Users WHERE Nitc_email_id = '$sender_id'";
          $result2 = mysqli_query($db,$query2);
          $row2 = mysqli_fetch_assoc($result2);
          $sender_name = $row2["User_name"]; 

          ?> 
      <div class="container" style="margin-top:40px;">
        <div class="row row-margin-bottom">
            <div class="col-md-12 no-padding lib-item " data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow ">
                        <div class="col-md-12 ">
                            <div class="lib-row lib-message">
                                <b><?php echo $sender_id; ?></b>

                                <!--<div class="lib-header-seperator"></div>-->
                            </div> 
<!---------------------------------------------------------------------------------------------------------------------------->
                            <?php 
                            
                            $find="SELECT * FROM Messages WHERE sender_id='$sender_id'";
                            $res=mysqli_query($db,$find);
                            while($r=mysqli_fetch_assoc($res)){
                              $is=(int)$r["msg_id"];
                            $ms=$r['message'];
                            $dt=$r['msg_date'];
                            $dtt=$r['msg_time'];
                            //$ed=$r['sender_id'];
                            //$d=$r[]
                            ?>
                            <div class="lib-row lib-data" name="emailid" >
                              <?php echo $ms;?><br>
                              
                                                        
                              <div class="lib-row lib-desc" style="text-align: right;">
                                  <?php echo $dt."\n ".$dtt; ?>
                              </div>
                              
                              </div>
                              
                            <?php }?> 
                            <a href="send_message.php?email=<?php echo $sender_id;?>"><center><button style="width: 10%;margin-left:1000px;margin-top:70px;margin-bottom:10px" type="submit" id="sold" name="sold" class="btn btn-primary" >MESSAGE</button></center></a>
                        </div> 
                      </div>    
                  </div>     
            </div>
          <div>  
      </div>
    <?php
  }
  if($is<=0)
    {
      echo'<a href="send_message.php"><center><button style="width: 80%;margin-top:100px;" type="submit" id="sold" name="sold" class="btn btn-primary" >CLICK HERE TO SEND MESSAGE</button></center></a>';
    }
  
?>

</form>




